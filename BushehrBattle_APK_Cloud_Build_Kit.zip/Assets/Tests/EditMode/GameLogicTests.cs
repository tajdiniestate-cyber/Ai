
#if UNITY_INCLUDE_TESTS
using NUnit.Framework;
using BushehrBattle;
using UnityEngine;
public class GameLogicTests {
 [Test] public void All300StagesHaveValidChaptersAndDurations() {
   for(int i=1;i<=300;i++){
     var s=StageCatalog.Get(i);
     Assert.That(s.number,Is.EqualTo(i));
     Assert.That(s.chapter,Is.InRange(1,10));
     Assert.That(s.durationSeconds,Is.InRange(360f,420f));
     Assert.That(s.bossNumber,Is.EqualTo(i%10==0?i/10:0));
   }
 }
 [Test] public void InfiniteWalletDoesNotDeductCurrency() {
   for(int i=0;i<1000;i++)Assert.IsTrue(InfiniteWallet.Spend(i*1000000L));
   Assert.AreEqual("∞",InfiniteWallet.DisplayBalance);
 }
 [Test] public void SquadCannotExceedFourOrDuplicateHeroes() {
   var go=new GameObject("test");
   try {
     var squad=go.AddComponent<HeroSquad>();
     for(int i=0;i<4;i++)Assert.IsTrue(squad.AddHero(new HeroDefinition{id="hero"+i}));
     Assert.IsFalse(squad.AddHero(new HeroDefinition{id="hero4"}));
     Assert.IsFalse(squad.AddHero(new HeroDefinition{id="hero0"}));
   } finally {Object.DestroyImmediate(go);}
 }

 [Test] public void HeroCatalogHasUniqueIdentifiers(){
  var ids=new System.Collections.Generic.HashSet<string>();
  foreach(var h in HeroCatalog.All){Assert.IsTrue(ids.Add(h.id));Assert.Greater(h.id.Length,0);}
 }
 [Test] public void AllStagesHaveExpectedChapterBoundaries(){
  for(int chapter=1;chapter<=10;chapter++){
   Assert.AreEqual(chapter,StageCatalog.Get((chapter-1)*30+1).chapter);
   Assert.AreEqual(chapter,StageCatalog.Get(chapter*30).chapter);
  }
 }
 [Test] public void RouteRejectsNanCoordinates(){
  Assert.IsFalse(RouteValidation.IsUsable(new[]{Vector3.zero,new Vector3(float.NaN,0,5)}));
 }
 [Test] public void RoadGraphFindsConnectedShortestRoute(){
  var graph=new RoadGraph();
  graph.nodes.Add(new RoadNode{osmId="a",position=new Vector3(0,0,0)});
  graph.nodes.Add(new RoadNode{osmId="b",position=new Vector3(1,0,0)});
  graph.nodes.Add(new RoadNode{osmId="c",position=new Vector3(2,0,0)});
  graph.edges.Add(new RoadEdge{from=0,to=1,length=1});
  graph.edges.Add(new RoadEdge{from=1,to=2,length=1});
  var path=graph.ShortestPath(0,2);
  Assert.AreEqual(3,path.Count);
  Assert.IsNull(graph.ShortestPath(2,0)); // directed one-way
 }
 [Test] public void RoadGraphRejectsInvalidEndpoints(){
  var graph=new RoadGraph();
  Assert.IsNull(graph.ShortestPath(0,1));
 }
 [Test] public void RouteRecordsSurviveSerialization(){
  var obj=new GameObject("map");
  try {
   var map=obj.AddComponent<BushehrMapImporter>();
   map.savedRoutes.Add(new BushehrMapImporter.RouteRecord{points=new System.Collections.Generic.List<Vector3>{Vector3.zero,new Vector3(4,0,0)}});
   var json=JsonUtility.ToJson(map);
   var obj2=new GameObject("map2");
   try {var map2=obj2.AddComponent<BushehrMapImporter>();JsonUtility.FromJsonOverwrite(json,map2);map2.RestoreRoutes();Assert.AreEqual(1,map2.drivableRoutes.Count);}
   finally {Object.DestroyImmediate(obj2);}
  }finally {Object.DestroyImmediate(obj);}
 }
 [Test] public void LargeDirectedGraphFindsShortestRoute(){
  var g=new RoadGraph();for(int i=0;i<1500;i++)g.nodes.Add(new RoadNode{osmId=i.ToString(),position=new Vector3(i,0,0)});
  for(int i=0;i<1499;i++)g.edges.Add(new RoadEdge{from=i,to=i+1,length=1});
  g.edges.Add(new RoadEdge{from=0,to=1499,length=5000});
  var path=g.ShortestPath(0,1499);Assert.NotNull(path);Assert.AreEqual(1500,path.Count);
  Assert.IsNull(g.ShortestPath(1499,0));
 }
 [Test] public void GraphRejectsInvalidEdges(){
  var g=new RoadGraph();g.nodes.Add(new RoadNode{position=Vector3.zero});g.nodes.Add(new RoadNode{position=Vector3.right});
  g.edges.Add(new RoadEdge{from=0,to=1,length=float.NaN});
  g.edges.Add(new RoadEdge{from=0,to=1,length=1});
  Assert.AreEqual(2,g.ShortestPath(0,1).Count);
 }

 [Test] public void All300StageDurationsAreWithinSevenMinutes(){
  for(int i=1;i<=300;i++)Assert.That(StageCatalog.Get(i).durationSeconds,Is.InRange(360f,420f));
 }
 [Test] public void BossScheduleHasThirtyUniqueBosses(){
  var bosses=new System.Collections.Generic.HashSet<int>();
  for(int i=1;i<=300;i++)if(StageCatalog.Get(i).bossNumber>0)Assert.IsTrue(bosses.Add(StageCatalog.Get(i).bossNumber));
  Assert.AreEqual(30,bosses.Count);
 }
}
#endif
