#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using BushehrBattle;
public static class SetupDemoScene {
 [MenuItem("Bushehr Battle/Create Truck + Top Down Camera")]
 static void Create(){
  var map=Object.FindObjectOfType<BushehrMapImporter>();
  if(map)map.RestoreRoutes();
  if(!map || map.drivableRoutes.Count==0){Debug.LogError("First import real OSM roads via Bushehr Battle menu.");return;}
  var truck=GameObject.CreatePrimitive(PrimitiveType.Cube);truck.name="ArmoredTruck_PLACEHOLDER";truck.transform.localScale=new Vector3(2,2,4);
  var auto=truck.AddComponent<AutoTruck>();auto.map=map;auto.routeIndex=0;truck.transform.position=map.drivableRoutes[0][0]+Vector3.up;
  var camera=Camera.main;
  if(!camera){var go=new GameObject("TopDownCamera");camera=go.AddComponent<Camera>();go.tag="MainCamera";}
  var follow=camera.gameObject.AddComponent<TopDownFollowCamera>();follow.target=truck.transform;
  camera.orthographic=true;camera.orthographicSize=30;
  if(!Object.FindObjectOfType<AdaptiveQuality>())new GameObject("AdaptiveQuality").AddComponent<AdaptiveQuality>();
  Selection.activeGameObject=truck;
  Debug.Log("Truck placeholder and top-down camera created. Assign an imported drivable route to AutoTruck per component API.");
 }
}
#endif
