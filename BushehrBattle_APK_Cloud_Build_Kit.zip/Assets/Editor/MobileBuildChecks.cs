#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
public static class MobileBuildChecks {
 [MenuItem("Bushehr Battle/Mobile Compatibility/Print Build Audit")]
 static void Audit(){
  Debug.Log("Target="+EditorUserBuildSettings.activeBuildTarget);
  Debug.Log("Android API="+PlayerSettings.Android.minSdkVersion+" | target="+PlayerSettings.Android.targetSdkVersion);
  Debug.Log("Android ARM64="+PlayerSettings.Android.targetArchitectures);
  Debug.Log("Graphics API automatic="+PlayerSettings.GetUseDefaultGraphicsAPIs(BuildTarget.Android));
  Debug.Log("iOS requires separate build, Metal, Xcode, provisioning and physical testing.");
  Debug.Log("Validate URP renderer, graphics API fallback, asset compression and actual FPS on hardware.");
 }
}
#endif