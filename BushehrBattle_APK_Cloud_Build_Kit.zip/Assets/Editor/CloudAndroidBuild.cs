#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using BushehrBattle;

public static class CloudAndroidBuild {
 public static void BuildApk() {
  string output="Builds/Android/BushehrBattle-Demo.apk";
  Directory.CreateDirectory(Path.GetDirectoryName(output));
  PlayerSettings.productName="نبرد بوشهر - آزمایشی";
  PlayerSettings.companyName="BushehrBattle";
  PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android,"com.bushehrbattle.demo");
  PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel23;
  PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
  PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
  EditorUserBuildSettings.buildAppBundle=false;
  var scene=MakeScene();
  var options=new BuildPlayerOptions {
   scenes=new[]{scene},locationPathName=output,target=BuildTarget.Android,
   options=BuildOptions.None
  };
  var result=BuildPipeline.BuildPlayer(options);
  if(result.summary.result!=UnityEditor.Build.Reporting.BuildResult.Succeeded)
   throw new Exception("Unity Android build failed: "+result.summary.result);
  Debug.Log("APK generated: "+Path.GetFullPath(output));
 }
 static string MakeScene() {
  Directory.CreateDirectory("Assets/Scenes");
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
  var sun=new GameObject("Sun");var light=sun.AddComponent<Light>();light.type=LightType.Directional;
  sun.transform.rotation=Quaternion.Euler(55,-35,0);
  var ground=GameObject.CreatePrimitive(PrimitiveType.Plane);ground.name="Demo ground (NOT real Bushehr map)";
  ground.transform.localScale=new Vector3(12,1,12);
  var truck=GameObject.CreatePrimitive(PrimitiveType.Cube);truck.name="Demo Truck";
  truck.transform.position=new Vector3(0,1,0);truck.transform.localScale=new Vector3(2,1.5f,4);
  truck.AddComponent<TruckHealth>();
  var cameraGo=new GameObject("Main Camera");cameraGo.tag="MainCamera";
  var camera=cameraGo.AddComponent<Camera>();camera.orthographic=true;camera.orthographicSize=22;
  var follow=cameraGo.AddComponent<TopDownFollowCamera>();follow.target=truck.transform;
  var mapGo=new GameObject("Demo route");
  var map=mapGo.AddComponent<BushehrMapImporter>();
  map.savedRoutes.Add(new BushehrMapImporter.RouteRecord {points=new System.Collections.Generic.List<Vector3>{
   new Vector3(0,1,0),new Vector3(0,1,22),new Vector3(15,1,22),new Vector3(15,1,-10),new Vector3(-12,1,-10),new Vector3(-12,1,0),new Vector3(0,1,0)
  }});
  map.RestoreRoutes();
  var mover=truck.AddComponent<AutoTruck>();mover.map=map;mover.loopRoute=true;
  var quality=new GameObject("Adaptive quality");quality.AddComponent<AdaptiveQuality>();
  string scenePath="Assets/Scenes/Demo.unity";
  EditorSceneManager.SaveScene(scene,scenePath);
  AssetDatabase.SaveAssets();
  return scenePath;
 }
}
#endif
