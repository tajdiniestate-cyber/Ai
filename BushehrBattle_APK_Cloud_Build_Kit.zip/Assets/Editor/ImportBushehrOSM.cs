#if UNITY_EDITOR
using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using BushehrBattle;

public static class ImportBushehrOSM {
  // City bounds: editable in the Overpass query. OSM coverage varies by district.
  const string Query="[out:xml][timeout:180];(way[\"highway\"](28.90,50.79,29.02,50.90);way[\"building\"](28.90,50.79,29.02,50.90););(._;>;);out body;";
  [MenuItem("Bushehr Battle/Download Real OSM Map")]
  static async void Download(){
    var url="https://overpass-api.de/api/interpreter";
    using(var req=new UnityWebRequest(url,"POST")){
      byte[] bytes=Encoding.UTF8.GetBytes("data="+UnityWebRequest.EscapeURL(Query));
      req.uploadHandler=new UploadHandlerRaw(bytes);req.downloadHandler=new DownloadHandlerBuffer();
      req.SetRequestHeader("Content-Type","application/x-www-form-urlencoded");
      req.timeout=240;
      var op=req.SendWebRequest();while(!op.isDone)await System.Threading.Tasks.Task.Delay(100);
      if(req.result!=UnityWebRequest.Result.Success){Debug.LogError("OSM download failed: "+req.error+". Use Import Local OSM XML instead.");return;}
      Directory.CreateDirectory("Assets/OSM");File.WriteAllText("Assets/OSM/bushehr.osm",req.downloadHandler.text);
      AssetDatabase.Refresh();ImportXml(req.downloadHandler.text);
    }
  }
  [MenuItem("Bushehr Battle/Import Local OSM XML")]
  static void ImportLocal(){
    var path=EditorUtility.OpenFilePanel("Select exported OSM XML", "", "osm,xml");
    if(!string.IsNullOrEmpty(path))ImportXml(File.ReadAllText(path));
  }
  static void ImportXml(string xml){
    var root=new GameObject("Bushehr_Real_OSM_Map");
    var importer=root.AddComponent<BushehrMapImporter>();
    try{importer.LoadOsmXml(xml);}catch(Exception ex){Debug.LogException(ex);UnityEngine.Object.DestroyImmediate(root);return;}
    Selection.activeGameObject=root;
    Debug.Log("Imported OSM road coordinates. Buildings are approximate proxy geometry. Add a truck and AutoTruck component to play.");
  }
}
#endif
