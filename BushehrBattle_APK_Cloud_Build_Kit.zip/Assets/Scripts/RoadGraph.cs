using System;
using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 [Serializable] public class RoadNode { public string osmId; public Vector3 position; }
 [Serializable] public class RoadEdge { public int from,to; public float length; }
 [Serializable] public class RoadGraph {
  public List<RoadNode> nodes=new List<RoadNode>();
  public List<RoadEdge> edges=new List<RoadEdge>();
  [NonSerialized] List<RoadEdge>[] adjacency;
  [NonSerialized] int cachedEdgeCount=-1;
  public void Rebuild(){
   adjacency=new List<RoadEdge>[nodes.Count];for(int i=0;i<nodes.Count;i++)adjacency[i]=new List<RoadEdge>();
   cachedEdgeCount=edges.Count;
   foreach(var e in edges)if(e!=null&&e.from>=0&&e.from<nodes.Count&&e.to>=0&&e.to<nodes.Count&&e.length>0&&!float.IsNaN(e.length)&&!float.IsInfinity(e.length))adjacency[e.from].Add(e);
  }
  // Binary min-heap: O((V+E) log V), including stale-entry handling.
  class Heap {
   struct Item {public int node;public float distance;public Item(int n,float d){node=n;distance=d;}}
   readonly List<Item> data=new List<Item>();
   public int Count=>data.Count;
   public void Push(int node,float d){data.Add(new Item(node,d));int i=data.Count-1;while(i>0){int p=(i-1)/2;if(data[p].distance<=d)break;data[i]=data[p];i=p;}data[i]=new Item(node,d);}
   public void Pop(out int node,out float distance){var root=data[0];node=root.node;distance=root.distance;int last=data.Count-1;var end=data[last];data.RemoveAt(last);if(last==0)return;int i=0;while(i*2+1<data.Count){int c=i*2+1;if(c+1<data.Count&&data[c+1].distance<data[c].distance)c++;if(data[c].distance>=end.distance)break;data[i]=data[c];i=c;}data[i]=end;}
  }
  public List<Vector3> ShortestPath(int start,int goal){
   if(nodes==null||start<0||goal<0||start>=nodes.Count||goal>=nodes.Count)return null;
   // Rebuild after deserialization or editor mutations.
   if(adjacency==null||adjacency.Length!=nodes.Count||cachedEdgeCount!=edges.Count)Rebuild();
   var dist=new float[nodes.Count];var prev=new int[nodes.Count];
   for(int i=0;i<nodes.Count;i++){dist[i]=float.PositiveInfinity;prev[i]=-1;}
   dist[start]=0;var queue=new Heap();queue.Push(start,0);
   while(queue.Count>0){
    queue.Pop(out int current,out float cost);
    if(cost>dist[current])continue;
    if(current==goal)break;
    foreach(var edge in adjacency[current]){
     float next=cost+edge.length;
     if(next<dist[edge.to]){dist[edge.to]=next;prev[edge.to]=current;queue.Push(edge.to,next);}
    }
   }
   if(float.IsPositiveInfinity(dist[goal]))return null;
   var path=new List<Vector3>();int cursor=goal,guard=0;
   while(cursor!=-1&&guard++<=nodes.Count){path.Add(nodes[cursor].position);cursor=prev[cursor];}
   if(guard>nodes.Count)return null;
   path.Reverse();return path;
  }
 }
}