using System;
using System.IO;
using UnityEngine;
namespace BushehrBattle {
 [Serializable] public class DeviceReport {
  public string platform,model,operatingSystem,gpu,gpuApi;
  public int ramMB,gpuMemoryMB,cores,screenWidth,screenHeight,qualityLevel,targetFrameRate;
 }
 public static class DeviceDiagnostics {
  public static DeviceReport Capture(){return new DeviceReport{
   platform=Application.platform.ToString(),model=SystemInfo.deviceModel,operatingSystem=SystemInfo.operatingSystem,
   gpu=SystemInfo.graphicsDeviceName,gpuApi=SystemInfo.graphicsDeviceType.ToString(),
   ramMB=SystemInfo.systemMemorySize,gpuMemoryMB=SystemInfo.graphicsMemorySize,cores=SystemInfo.processorCount,
   screenWidth=Screen.width,screenHeight=Screen.height,qualityLevel=QualitySettings.GetQualityLevel(),targetFrameRate=Application.targetFrameRate
  };}
  public static string SaveLocal(){
   string path=Path.Combine(Application.persistentDataPath,"device_report.json");
   File.WriteAllText(path,JsonUtility.ToJson(Capture(),true));return path;
  }
 }
}