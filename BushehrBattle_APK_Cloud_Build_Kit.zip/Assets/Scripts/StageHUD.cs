using UnityEngine;
using UnityEngine.UI;
namespace BushehrBattle {
 public class StageHUD : MonoBehaviour {
  public BattleRuntime battle;
  public Text timerText,healthText,stageText,statusText;
  public TruckHealth health;
  void Update(){
   if(battle==null)return;
   if(timerText) {int secs=Mathf.CeilToInt(battle.RemainingSeconds);timerText.text=(secs/60).ToString("00")+":"+(secs%60).ToString("00");}
   if(healthText&&health)healthText.text=Mathf.CeilToInt(health.currentHealth)+" / "+Mathf.CeilToInt(health.maxHealth);
   if(stageText)stageText.text="مرحله "+battle.stage;
   if(statusText)statusText.text=battle.stageFinished?"پیروزی":battle.stageFailed?"شکست":"";
  }
 }
}