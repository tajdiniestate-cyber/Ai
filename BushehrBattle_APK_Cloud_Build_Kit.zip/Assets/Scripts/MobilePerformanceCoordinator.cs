using UnityEngine;
namespace BushehrBattle {
 // One authority for adaptive quality, thermal state, and gameplay budget.
 [DefaultExecutionOrder(-100)]
 public class MobilePerformanceCoordinator : MonoBehaviour {
  public AdaptiveQuality quality;
  public BattleRuntime battle;
  public float sampleInterval=4f;
  public int normalEnemyCap=32, lowEnemyCap=12;
  public bool conservativeMode;
  public float smoothedFrameMs {get;private set;}
  float elapsed;int frames;int badWindows,goodWindows;
  void Awake(){if(quality==null)quality=FindFirstObjectByType<AdaptiveQuality>();if(battle==null)battle=FindFirstObjectByType<BattleRuntime>();}
  void Update(){
   if(!Application.isFocused||Time.unscaledDeltaTime<=0||Time.unscaledDeltaTime>.25f)return;
   elapsed+=Time.unscaledDeltaTime;frames++;
   if(elapsed<Mathf.Max(2,sampleInterval))return;
   smoothedFrameMs=1000f*elapsed/Mathf.Max(1,frames);elapsed=0;frames=0;
   float budget=1000f/Mathf.Max(20,quality!=null?quality.TargetFps:30);
   if(smoothedFrameMs>budget*1.4f){badWindows++;goodWindows=0;}
   else if(smoothedFrameMs<budget*.95f){goodWindows++;badWindows=0;}
   else {badWindows=0;goodWindows=0;}
   if(badWindows>=3){SetConservative(true);badWindows=0;}
   if(goodWindows>=8){SetConservative(false);goodWindows=0;}
  }
  public void SetConservative(bool value){
   conservativeMode=value;
   if(battle!=null)battle.maxAlive=Mathf.Max(1,value?lowEnemyCap:normalEnemyCap);
   if(quality!=null)quality.SetBatterySaver(value);
  }
  void OnApplicationPause(bool pause){elapsed=0;frames=0;badWindows=0;goodWindows=0;}
  void OnApplicationFocus(bool focus){elapsed=0;frames=0;badWindows=0;goodWindows=0;}
 }
}