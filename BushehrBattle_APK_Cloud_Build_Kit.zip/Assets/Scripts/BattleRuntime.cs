using System;
using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 public enum EnemyKind { Infantry, Robot, Mutant, Armored, Drone, Boss }
 public class BattleRuntime : MonoBehaviour {
  public Transform truck;
  public GameObject[] enemyPrefabs;
  public GameObject bossPrefab;
  public Transform[] spawnPoints;
  [Range(1,300)] public int stage=1;
  public int maxAlive=32;
  public bool stageFinished, stageFailed;
  public int enemiesDefeated;
  public event Action<int> OnStageComplete;
  public event Action<int> OnStageFailed;
  readonly List<GameObject> alive=new List<GameObject>();
  float elapsed,spawnClock;bool bossSpawned;
  System.Random rng;
  StageSpec spec;
  void Start(){stage=Mathf.Clamp(stage,1,300);spec=StageCatalog.Get(stage);rng=new System.Random(stage*7919);}
  void Update(){
   if(stageFinished||stageFailed||Time.timeScale<=0)return;
   if(truck==null){stageFailed=true;OnStageFailed?.Invoke(stage);return;}
   var hp=truck.GetComponent<TruckHealth>();
   if(hp!=null&&hp.IsDestroyed){stageFailed=true;OnStageFailed?.Invoke(stage);return;}
   elapsed+=Time.deltaTime;spawnClock-=Time.deltaTime;
   for(int i=alive.Count-1;i>=0;i--)if(alive[i]==null)alive.RemoveAt(i);
   if(spec.bossNumber>0&&!bossSpawned&&elapsed>=spec.durationSeconds-65){
    bossSpawned=true;
    if(bossPrefab==null){Debug.LogError("Boss stage requires a boss prefab.");stageFailed=true;OnStageFailed?.Invoke(stage);return;}
    if(!SpawnPrefab(bossPrefab,true)){stageFailed=true;OnStageFailed?.Invoke(stage);return;}
   }
   if(elapsed>=spec.durationSeconds){
    if(bossSpawned&&alive.Exists(x=>x!=null&&x.GetComponent<SimpleEnemyAI>()?.isBoss==true))return;
    stageFinished=true;OnStageComplete?.Invoke(stage);return;
   }
   if(spawnClock<=0&&elapsed<spec.durationSeconds-10&&alive.Count<Mathf.Max(1,maxAlive)){
    if(enemyPrefabs!=null&&enemyPrefabs.Length>0){var prefab=enemyPrefabs[rng.Next(enemyPrefabs.Length)];if(prefab!=null)SpawnPrefab(prefab);}
    spawnClock=Mathf.Max(.65f,3.5f/(1f+(stage-1)/45f));
   }
  }
  bool SpawnPrefab(GameObject prefab,bool boss=false){
   if(prefab==null||truck==null)return false;
   Vector3 pos;
   if(spawnPoints!=null&&spawnPoints.Length>0){
    var point=spawnPoints[rng.Next(spawnPoints.Length)];
    pos=point==null?truck.position+Vector3.forward*25:point.position;
   }else{
    float angle=(float)rng.NextDouble()*Mathf.PI*2;
    pos=truck.position+new Vector3(Mathf.Cos(angle),0,Mathf.Sin(angle))*rng.Next(20,40);
   }
   var enemy=Instantiate(prefab,pos,Quaternion.identity);
   var ai=enemy.GetComponent<SimpleEnemyAI>();
   if(ai==null){Debug.LogError("Enemy prefab missing SimpleEnemyAI: "+prefab.name);Destroy(enemy);return false;}
   ai.target=truck;ai.isBoss=boss;ai.health*=1+stage*.07f;ai.Died+=()=>enemiesDefeated++;
   alive.Add(enemy);return true;
  }
  public float RemainingSeconds=>Mathf.Max(0,spec.durationSeconds-elapsed);
 }
 public class SimpleEnemyAI : MonoBehaviour {
  public Transform target;
  public float speed=2.4f,health=100,attackRange=2f,damagePerSecond=5;
  public bool isBoss;
  public event Action Died;
  bool dead;
  void Update(){
   if(dead||target==null)return;
   Vector3 delta=target.position-transform.position;delta.y=0;
   if(delta.sqrMagnitude>attackRange*attackRange){
    transform.position+=delta.normalized*speed*Time.deltaTime;
    if(delta.sqrMagnitude>.01f)transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(delta),Time.deltaTime*5);
   }else{
    var hp=target.GetComponent<TruckHealth>();
    if(hp!=null)hp.TakeDamage(damagePerSecond*Time.deltaTime);
   }
  }
  public void TakeDamage(float amount){
   if(dead)return;
   health-=Mathf.Max(0,amount);
   if(health<=0){dead=true;Died?.Invoke();Destroy(gameObject);}
  }
 }
 public class TruckHealth : MonoBehaviour {
  public float maxHealth=1000,currentHealth=1000;
  public bool IsDestroyed=>currentHealth<=0;
  public void TakeDamage(float amount){currentHealth=Mathf.Max(0,currentHealth-Mathf.Max(0,amount));}
  public void Repair(float amount){currentHealth=Mathf.Min(maxHealth,currentHealth+Mathf.Max(0,amount));}
 }
}