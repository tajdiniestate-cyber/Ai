using UnityEngine;
namespace BushehrBattle {
 public class MobilePlatformSupport : MonoBehaviour {
  public bool keepScreenAwakeDuringBattle=true;
  public bool pauseWhenBackgrounded=true;
  public bool useAndroidBackToPause=true;
  public bool IsPaused {get;private set;}
  void Awake(){Application.runInBackground=false;Screen.sleepTimeout=keepScreenAwakeDuringBattle?SleepTimeout.NeverSleep:SleepTimeout.SystemSetting;}
  void Update(){
   if(useAndroidBackToPause && Input.GetKeyDown(KeyCode.Escape))SetPaused(!IsPaused);
  }
  void OnApplicationPause(bool paused){if(paused&&pauseWhenBackgrounded)SetPaused(true);}
  public void SetPaused(bool paused){IsPaused=paused;Time.timeScale=paused?0:1;AudioListener.pause=paused;}
  void OnDestroy(){if(IsPaused){Time.timeScale=1;AudioListener.pause=false;}Screen.sleepTimeout=SleepTimeout.SystemSetting;}
 }
}