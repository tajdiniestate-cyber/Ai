using UnityEngine;
namespace BushehrBattle {
 [RequireComponent(typeof(RectTransform))]
 public class SafeAreaLayout : MonoBehaviour {
  RectTransform rect;
  Rect lastSafe;Vector2Int lastSize;
  void Awake(){rect=GetComponent<RectTransform>();Refresh();}
  void Update(){if(Screen.safeArea!=lastSafe||Screen.width!=lastSize.x||Screen.height!=lastSize.y)Refresh();}
  void Refresh(){
   if(rect==null||Screen.width<=0||Screen.height<=0)return;
   lastSafe=Screen.safeArea;lastSize=new Vector2Int(Screen.width,Screen.height);
   rect.anchorMin=new Vector2(lastSafe.xMin/Screen.width,lastSafe.yMin/Screen.height);
   rect.anchorMax=new Vector2(lastSafe.xMax/Screen.width,lastSafe.yMax/Screen.height);
   rect.offsetMin=Vector2.zero;rect.offsetMax=Vector2.zero;
  }
 }
}