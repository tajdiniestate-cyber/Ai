using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 public static class RouteValidation {
  public static bool IsUsable(IReadOnlyList<Vector3> route){
   if(route==null||route.Count<2)return false;
   float distance=0;
   for(int i=0;i<route.Count;i++){
    var p=route[i];
    if(float.IsNaN(p.x)||float.IsNaN(p.z)||float.IsInfinity(p.x)||float.IsInfinity(p.z))return false;
    if(i>0)distance+=Vector3.Distance(route[i-1],p);
   }
   return distance>1f;
  }
 }
}