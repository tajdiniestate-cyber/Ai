using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 // Opt-in pool: requires enemies to call Release instead of Destroy.
 public class EnemyPool : MonoBehaviour {
  public GameObject prefab;
  public int prewarm=16,maxInactive=64;
  readonly Stack<GameObject> inactive=new Stack<GameObject>();
  readonly HashSet<GameObject> active=new HashSet<GameObject>();
  void Start(){if(prefab==null){Debug.LogWarning("EnemyPool prefab not assigned");return;}for(int i=0;i<Mathf.Clamp(prewarm,0,256);i++){var obj=Instantiate(prefab,transform);obj.SetActive(false);inactive.Push(obj);}}
  public GameObject Acquire(Vector3 position){
   if(prefab==null)return null;
   var obj=inactive.Count>0?inactive.Pop():Instantiate(prefab,transform);
   obj.transform.position=position;obj.transform.rotation=Quaternion.identity;
   obj.SetActive(true);active.Add(obj);return obj;
  }
  public void Release(GameObject obj){
   if(obj==null||!active.Remove(obj))return;
   obj.SetActive(false);
   if(inactive.Count>=maxInactive)Destroy(obj);else inactive.Push(obj);
  }
  void OnDestroy(){active.Clear();inactive.Clear();}
 }
}