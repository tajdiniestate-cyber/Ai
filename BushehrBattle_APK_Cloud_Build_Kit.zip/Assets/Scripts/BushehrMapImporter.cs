using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;
using UnityEngine;

namespace BushehrBattle {
  // Converts real OpenStreetMap geometry to a lightweight Unity scene.
  public class BushehrMapImporter : MonoBehaviour {
    [Header("Geographic origin (Bushehr)")]
    public double originLatitude = 28.96, originLongitude = 50.83;
    [Header("Scale")]
    public float worldScale = 0.1f; // 1 real meter = 0.1 Unity units
    public Material roadMaterial, buildingMaterial, waterMaterial;
    public float roadWidth = 1.2f;
    [Min(1)] public int maxRoadMeshesPerImport=25000;
    [Min(1)] public int maxBuildingProxiesPerImport=25000;
    [Serializable] public class RouteRecord {public List<Vector3> points=new List<Vector3>();}
    public List<RouteRecord> savedRoutes=new List<RouteRecord>();
    public RoadGraph roadGraph=new RoadGraph();
    [NonSerialized] public List<Vector3[]> drivableRoutes=new List<Vector3[]>();
    public void OnEnable(){RestoreRoutes();roadGraph.Rebuild();}
    public void RestoreRoutes(){
      drivableRoutes=new List<Vector3[]>();
      foreach(var record in savedRoutes)if(record!=null && RouteValidation.IsUsable(record.points))drivableRoutes.Add(record.points.ToArray());
    }
    static readonly CultureInfo CI = CultureInfo.InvariantCulture;
    Vector3 Project(double lat, double lon) {
      double north = (lat - originLatitude) * 111320.0;
      double east = (lon - originLongitude) * 111320.0 * Math.Cos(originLatitude * Math.PI / 180);
      return new Vector3((float)(east * worldScale), 0, (float)(north * worldScale));
    }
    public void LoadOsmXml(string xml) {
      if(string.IsNullOrWhiteSpace(xml))throw new ArgumentException("OSM XML is empty");
      // Parse and validate before mutating scene; prevent unbounded imports.
      if(xml.Length>60_000_000)throw new ArgumentException("OSM XML exceeds 60MB safe import limit; split into tiles.");
      var doc = XDocument.Parse(xml);
      if(doc.Root==null || doc.Root.Name.LocalName!="osm")throw new ArgumentException("Expected an OSM XML document.");
      if(!doc.Descendants("node").Any())throw new ArgumentException("OSM document contains no nodes.");
      // Preflight every referenced node and construct valid road records BEFORE replacing the old map.
      var validNodeIds=new HashSet<string>();
      foreach(var n in doc.Descendants("node")) {
        var id=(string)n.Attribute("id");
        if(string.IsNullOrEmpty(id))continue;
        if(double.TryParse((string)n.Attribute("lat"),NumberStyles.Float,CI,out var la) &&
           double.TryParse((string)n.Attribute("lon"),NumberStyles.Float,CI,out var lo) &&
           la>=-90 && la<=90 && lo>=-180 && lo<=180)validNodeIds.Add(id);
      }
      if(validNodeIds.Count<2)throw new ArgumentException("OSM has insufficient valid nodes.");
      int validRoads=0;
      foreach(var way in doc.Descendants("way")) {
        bool highway=way.Elements("tag").Any(tag=>(string)tag.Attribute("k")=="highway");
        if(!highway)continue;
        var refs=way.Elements("nd").Select(n=>(string)n.Attribute("ref")).ToArray();
        if(refs.Length>=2 && refs.All(id=>id!=null&&validNodeIds.Contains(id)))validRoads++;
      }
      if(validRoads==0)throw new ArgumentException("OSM has no complete road ways; current map preserved.");
      var generated = new List<Transform>();
      foreach(Transform child in transform) if(child.name.StartsWith("Road_") || child.name.StartsWith("Building_")) generated.Add(child);
      foreach(var child in generated) { if(Application.isPlaying) Destroy(child.gameObject); else DestroyImmediate(child.gameObject); }
      drivableRoutes.Clear();savedRoutes.Clear();roadGraph=new RoadGraph();
      var nodes=new Dictionary<string,Vector3>();
      foreach(var n in doc.Descendants("node")){
        var id=(string)n.Attribute("id");
        if(string.IsNullOrEmpty(id))continue;
        if(!double.TryParse((string)n.Attribute("lat"),NumberStyles.Float,CI,out var lat) ||
           !double.TryParse((string)n.Attribute("lon"),NumberStyles.Float,CI,out var lon))continue;
        if(lat < -90 || lat > 90 || lon < -180 || lon > 180)continue;
        nodes[id]=Project(lat,lon);
      }
      var nodeIndices=new Dictionary<string,int>();
      int roads=0, buildings=0;
      foreach (var way in doc.Descendants("way")) {
        var tags = new Dictionary<string,string>();
        foreach(var tag in way.Elements("tag")) {
          var k=(string)tag.Attribute("k"); if(!string.IsNullOrEmpty(k))tags[k]=(string)tag.Attribute("v")??"";
        }
        var refs = way.Elements("nd").Select(n=>(string)n.Attribute("ref")).ToArray();
        if(refs.Any(id=>id==null||!nodes.ContainsKey(id)))continue;
        var points = refs.Select(id=>nodes[id]).ToArray();
        if(points.Length<2) continue;
        if(tags.ContainsKey("highway") && !new[]{"footway","path","steps","cycleway","pedestrian","construction","proposed","raceway","bridleway","corridor","platform"}.Contains(tags["highway"]) && (!tags.TryGetValue("access",out var access)||access!="private") && (!tags.TryGetValue("motor_vehicle",out var motor)||motor!="no")) {
          var width = tags["highway"] == "primary" || tags["highway"] == "trunk" ? roadWidth*1.8f : roadWidth;
          if(RouteValidation.IsUsable(points)) {
            if(roads<maxRoadMeshesPerImport)BuildRoad(points,width,roadMaterial, "Road_"+roads++);
            bool reverse=tags.TryGetValue("oneway",out var oneWay)&&oneWay=="-1";
            bool oneDirection=reverse||oneWay=="yes"||oneWay=="1"||tags.ContainsKey("junction")&&tags["junction"]=="roundabout";
            if(reverse){Array.Reverse(points);Array.Reverse(refs);}
            drivableRoutes.Add(points);
            savedRoutes.Add(new RouteRecord{points=new List<Vector3>(points)});
            for(int i=0;i<refs.Length;i++)if(!nodeIndices.ContainsKey(refs[i])){
              int index=roadGraph.nodes.Count;nodeIndices[refs[i]]=index;
              roadGraph.nodes.Add(new RoadNode{osmId=refs[i],position=nodes[refs[i]]});
            }
            for(int i=1;i<refs.Length;i++){
              int from=nodeIndices[refs[i-1]],to=nodeIndices[refs[i]];
              float length=Vector3.Distance(nodes[refs[i-1]],nodes[refs[i]]);
              if(length<=0.0001f)continue;
              roadGraph.edges.Add(new RoadEdge{from=from,to=to,length=length});
              if(!oneDirection)roadGraph.edges.Add(new RoadEdge{from=to,to=from,length=length});
            }
          }
        } else if(tags.ContainsKey("building") && points.Length>=4) {
          // Simplified rectangular proxy only; not an exact building reconstruction.
          var minX=points.Min(p=>p.x);var maxX=points.Max(p=>p.x);
          var minZ=points.Min(p=>p.z);var maxZ=points.Max(p=>p.z);
          var h=1.0f;
          if(tags.TryGetValue("building:levels",out var levels) && float.TryParse(levels,NumberStyles.Float,CI,out var lv)) h=Mathf.Clamp(lv*.9f,.8f,12f);
          if(maxX-minX>200 || maxZ-minZ>200 || maxX-minX<.05f || maxZ-minZ<.05f)continue;
          if(buildings>=maxBuildingProxiesPerImport)continue;
          var obj=GameObject.CreatePrimitive(PrimitiveType.Cube);obj.name="Building_"+buildings++;
          var collider=obj.GetComponent<Collider>();if(collider){if(Application.isPlaying)Destroy(collider);else DestroyImmediate(collider);}
          obj.transform.SetParent(transform,false);obj.transform.position=new Vector3((minX+maxX)/2,h/2,(minZ+maxZ)/2);
          obj.transform.localScale=new Vector3(Mathf.Max(.4f,maxX-minX),h,Mathf.Max(.4f,maxZ-minZ));
          if(buildingMaterial) obj.GetComponent<Renderer>().sharedMaterial=buildingMaterial;
        }
      }
      roadGraph.Rebuild();
      Debug.Log($"OSM imported: {roads} road ways, {buildings} approximate buildings, {drivableRoutes.Count} routes.");
    }
    void BuildRoad(Vector3[] pts,float width,Material mat,string name) {
      var verts=new List<Vector3>();var tris=new List<int>();
      for(int i=0;i<pts.Length-1;i++) {
        Vector3 a=pts[i],b=pts[i+1],d=(b-a).normalized;
        if(d.sqrMagnitude<.001f)continue;
        Vector3 offset=new Vector3(-d.z,0,d.x)*width*.5f;
        int k=verts.Count;verts.Add(a-offset);verts.Add(a+offset);verts.Add(b-offset);verts.Add(b+offset);
        tris.AddRange(new[]{k,k+1,k+2,k+1,k+3,k+2});
      }
      var mesh=new Mesh{indexFormat=UnityEngine.Rendering.IndexFormat.UInt32};mesh.SetVertices(verts);mesh.SetTriangles(tris,0);mesh.RecalculateNormals();
      var go=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(transform,false);
      go.GetComponent<MeshFilter>().sharedMesh=mesh;
      if(mat)go.GetComponent<MeshRenderer>().sharedMaterial=mat;
    }
  }
}
