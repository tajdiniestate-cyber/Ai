using System;
using UnityEngine;
namespace BushehrBattle {
 [Serializable] public struct StageSpec {
  public int number,chapter,bossNumber,difficulty;
  public float durationSeconds;
  public string district;
 }
 public static class StageCatalog {
  static readonly string[] districts={"Bushehr Coast","Old Bushehr","Rishehr","Central Bushehr","Port District","Outer Roads","Night City","Contaminated Zone","Damaged City","Final Defense"};
  public static StageSpec Get(int number){
   if(number<1||number>300)throw new ArgumentOutOfRangeException(nameof(number),"Stage must be 1..300");
   int chapter=(number-1)/30;
   return new StageSpec{number=number,chapter=chapter+1,district=districts[chapter],durationSeconds=360+((number-1)%5)*15,difficulty=1+(number-1)/5,bossNumber=number%10==0?number/10:0};
  }
 }
}