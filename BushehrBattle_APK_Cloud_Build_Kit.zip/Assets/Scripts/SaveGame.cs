using System;
using System.IO;
using UnityEngine;
namespace BushehrBattle {
 [Serializable] public class SaveData {
  public int schema=1;
  public int highestCompletedStage=0;
  public string[] unlockedHeroIds=new string[0];
  public string[] equippedWeaponIds=new string[0];
 }
 public static class SaveGame {
  static string PathName=>Path.Combine(Application.persistentDataPath,"bushehr_save.json");
  static string Backup=>PathName+".bak";
  public static void Write(SaveData data){
   if(data==null)throw new ArgumentNullException(nameof(data));
   if(data.highestCompletedStage<0||data.highestCompletedStage>300)throw new ArgumentOutOfRangeException(nameof(data.highestCompletedStage));
   string json=JsonUtility.ToJson(data);
   string temp=PathName+".tmp";
   Directory.CreateDirectory(Application.persistentDataPath);
   File.WriteAllText(temp,json);
   if(File.Exists(PathName)){
    // File.Replace is not implemented on every Android filesystem/runtime.
    try{File.Replace(temp,PathName,Backup);}
    catch(Exception ex) when (ex is PlatformNotSupportedException || ex is IOException || ex is UnauthorizedAccessException){
     if(File.Exists(PathName))File.Copy(PathName,Backup,true);
     File.Copy(temp,PathName,true);File.Delete(temp);
    }
   }else{File.Move(temp,PathName);}
  }
  public static SaveData Read(){
   foreach(string path in new[]{PathName,Backup}){
    if(!File.Exists(path))continue;
    try{
     var data=JsonUtility.FromJson<SaveData>(File.ReadAllText(path));
     if(data!=null&&data.schema==1&&data.highestCompletedStage>=0&&data.highestCompletedStage<=300)return data;
    }catch(Exception e){Debug.LogWarning("Save read failed: "+e.Message);}
   }
   return new SaveData();
  }
 }
}