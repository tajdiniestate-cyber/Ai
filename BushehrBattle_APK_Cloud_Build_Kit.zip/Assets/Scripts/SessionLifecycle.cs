using UnityEngine;
namespace BushehrBattle {
 // Persists progress only on completed stages and on app background.
 public class SessionLifecycle : MonoBehaviour {
  public BattleRuntime battle;
  public MobilePlatformSupport mobile;
  bool subscribed;
  void OnEnable(){if(battle==null)battle=FindFirstObjectByType<BattleRuntime>();if(battle!=null){battle.OnStageComplete+=Completed;subscribed=true;}}
  void OnDisable(){if(subscribed&&battle!=null)battle.OnStageComplete-=Completed;subscribed=false;}
  void Completed(int stage){try{var data=SaveGame.Read();data.highestCompletedStage=Mathf.Max(data.highestCompletedStage,stage);SaveGame.Write(data);}catch(System.Exception ex){Debug.LogError("Save failed: "+ex.Message);}}
  void OnApplicationPause(bool pause){if(pause)TrySave();}
  void OnApplicationFocus(bool focused){if(!focused)TrySave();}
  void TrySave(){try{var data=SaveGame.Read();SaveGame.Write(data);}catch(System.Exception ex){Debug.LogWarning("Background save failed: "+ex.Message);}}
 }
}