using UnityEngine;
namespace BushehrBattle {
 public class TopDownFollowCamera : MonoBehaviour {
  public Transform target; public Vector3 offset=new Vector3(0,35,-22); public float smooth=5f;
  void LateUpdate(){if(!target)return;transform.position=Vector3.Lerp(transform.position,target.position+offset,Time.deltaTime*smooth);transform.rotation=Quaternion.LookRotation(target.position-transform.position,Vector3.up);}
 }
}
