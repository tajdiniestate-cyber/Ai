using UnityEngine;
namespace BushehrBattle {
 public class AutoTruck : MonoBehaviour {
  public BushehrMapImporter map;
  [Min(.1f)] public float speed=6f, acceleration=8f, turnSpeed=5f, waypointDistance=1.5f;
  public int routeIndex=0;
  public bool loopRoute=false;
  public bool completed;
  int pointIndex; float currentSpeed;
  Vector3[] activePath;
  public bool NavigateOsmNodes(int startNode,int endNode){
   if(map==null)return false;
   var result=map.roadGraph.ShortestPath(startNode,endNode);
   if(!RouteValidation.IsUsable(result))return false;
   activePath=result.ToArray();pointIndex=0;completed=false;currentSpeed=0;return true;
  }
  void Start(){if(!map)map=FindFirstObjectByType<BushehrMapImporter>();}
  void Update(){
   if(completed||map==null||Time.timeScale<=0)return;
   if(activePath==null && (map.drivableRoutes==null||map.drivableRoutes.Count==0))return;
   var route=activePath??map.drivableRoutes[Mathf.Clamp(routeIndex,0,map.drivableRoutes.Count-1)];
   if(route==null||route.Length<2)return;
   if(float.IsNaN(speed)||float.IsInfinity(speed)||speed<=0||float.IsNaN(acceleration)||acceleration<=0)return;
   pointIndex=Mathf.Clamp(pointIndex,0,route.Length-1);
   var target=route[pointIndex];var delta=target-transform.position;delta.y=0;
   int skips=0;
   while(delta.magnitude<=Mathf.Max(.05f,waypointDistance)&&skips++<route.Length){
    if(pointIndex==route.Length-1){if(!loopRoute || activePath!=null){completed=true;currentSpeed=0;return;}pointIndex=0;}
    else pointIndex++;
    target=route[pointIndex];delta=target-transform.position;delta.y=0;
   }
   if(delta.sqrMagnitude<.0001f)return;
   currentSpeed=Mathf.MoveTowards(currentSpeed,speed,acceleration*Time.deltaTime);
   transform.position=Vector3.MoveTowards(transform.position,target,currentSpeed*Time.deltaTime);
   transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(delta),Mathf.Clamp01(turnSpeed*Time.deltaTime));
  }
 }
}