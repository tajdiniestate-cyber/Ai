using System;
using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 [Serializable] public class HeroDefinition {
  public string id,displayName;
  public float damageMultiplier=1,defenseMultiplier=1,fireRateMultiplier=1;
 }
 public class HeroSquad : MonoBehaviour {
  public List<HeroDefinition> selected=new List<HeroDefinition>();
  public bool AddHero(HeroDefinition hero){
   if(hero==null||string.IsNullOrWhiteSpace(hero.id)||selected.Count>=4)return false;
   if(selected.Exists(h=>h!=null&&h.id==hero.id))return false;
   selected.Add(hero);return true;
  }
  public float DamageBonus(){
   float bonus=1;
   foreach(var h in selected)if(h!=null)bonus+=Mathf.Max(0,h.damageMultiplier-1);
   return bonus;
  }
 }
 [Serializable] public class WeaponDefinition {
  public string id,displayName;
  public float damage=10,range=25,shotsPerSecond=2;
  public int level=1;
 }
 public class AutoTurret : MonoBehaviour {
  public WeaponDefinition weapon=new WeaponDefinition();
  public Transform muzzle;
  public HeroSquad squad;
  public LayerMask enemyLayers=-1;
  public int targetBufferSize=64;
  Collider[] hits;
  float cooldown;
  void Awake(){hits=new Collider[Mathf.Clamp(targetBufferSize,8,256)];}
  void Update(){
   cooldown-=Time.deltaTime;if(cooldown>0)return;
   var origin=muzzle==null?transform:muzzle;
   int count=Physics.OverlapSphereNonAlloc(origin.position,Mathf.Max(.1f,weapon.range),hits,enemyLayers);
   SimpleEnemyAI best=null;float dist=float.MaxValue;
   for(int i=0;i<count;i++){
    var e=hits[i]==null?null:hits[i].GetComponentInParent<SimpleEnemyAI>();
    if(e==null||e.health<=0)continue;
    float d=(e.transform.position-origin.position).sqrMagnitude;
    if(d<dist){dist=d;best=e;}
   }
   if(count==hits.Length && Time.frameCount%300==0)Debug.LogWarning("Turret overlap buffer full: increase targetBufferSize or reduce nearby enemies.");
   if(best==null)return;
   Vector3 dir=best.transform.position-origin.position;dir.y=0;
   if(dir.sqrMagnitude>.001f)transform.rotation=Quaternion.LookRotation(dir);
   best.TakeDamage(Mathf.Max(0,weapon.damage)*Mathf.Max(1,weapon.level)*(squad==null?1:squad.DamageBonus()));
   cooldown=1f/Mathf.Max(.1f,weapon.shotsPerSecond);
  }
 }
 public static class InfiniteWallet {
  public static bool CanAfford(long cost)=>cost>=0;
  public static bool Spend(long cost)=>cost>=0;
  public static string DisplayBalance=>"∞";
 }
}