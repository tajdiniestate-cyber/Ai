using System.Collections.Generic;
using UnityEngine;
namespace BushehrBattle {
 // Disables renderers in distant chunks; retains colliders and route graph.
 // Assign chunk roots manually or with the editor grouping utility.
 public class MapChunkVisibility : MonoBehaviour {
  public Transform target;
  public Transform[] chunkRoots;
  [Min(1)]public float activeRadius=250f;
  [Min(0)]public float hysteresis=35f;
  [Min(.1f)]public float updateInterval=.75f;
  [Min(1)]public int chunksPerTick=12;
  readonly Dictionary<Transform,Renderer[]> cache=new Dictionary<Transform,Renderer[]>();
  readonly Dictionary<Transform,float> radii=new Dictionary<Transform,float>();
  readonly Dictionary<Transform,bool> states=new Dictionary<Transform,bool>();
  int cursor;float nextUpdate;
  void Start(){if(target==null){var truck=FindFirstObjectByType<AutoTruck>();if(truck!=null)target=truck.transform;}BuildCache();}
  public void BuildCache(){
   cache.Clear();radii.Clear();states.Clear();cursor=0;
   if(chunkRoots==null)return;
   foreach(var root in chunkRoots){
    if(root==null)continue;
    var renderers=root.GetComponentsInChildren<Renderer>(true);cache[root]=renderers;
    float extent=0;
    foreach(var r in renderers)if(r!=null){var bounds=r.bounds;extent=Mathf.Max(extent,Vector3.Distance(root.position,bounds.center)+bounds.extents.magnitude);}
    radii[root]=extent;states[root]=true;
   }
  }
  void Update(){
   if(target==null||chunkRoots==null||chunkRoots.Length==0||Time.unscaledTime<nextUpdate)return;
   nextUpdate=Time.unscaledTime+updateInterval;
   for(int i=0;i<Mathf.Min(chunksPerTick,chunkRoots.Length);i++){
    var root=chunkRoots[cursor++%chunkRoots.Length];if(root==null)continue;
    if(!cache.TryGetValue(root,out var renderers))continue;
    var delta=root.position-target.position;delta.y=0;
    bool old=states.TryGetValue(root,out var current)?current:true;
    float radius=Mathf.Max(1f,activeRadius)+(radii.TryGetValue(root,out var extent)?extent:0);
    float threshold=old?radius+Mathf.Max(0,hysteresis):Mathf.Max(0,radius-Mathf.Max(0,hysteresis));
    bool visible=delta.sqrMagnitude<=threshold*threshold;
    if(old==visible)continue;
    states[root]=visible;
    foreach(var r in renderers)if(r!=null)r.enabled=visible;
   }
  }
 }
}