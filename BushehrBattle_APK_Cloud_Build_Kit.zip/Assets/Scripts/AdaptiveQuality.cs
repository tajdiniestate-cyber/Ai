using UnityEngine;
namespace BushehrBattle {
 public class AdaptiveQuality : MonoBehaviour {
  [Range(20,120)] public int requestedFps=60;
  [Range(0.5f,1f)] public float minimumRenderScale=.7f;
  public float sampleSeconds=8f,changeCooldown=25f;
  public bool batterySaver;
  float elapsed,frames,lastChange=-999f;
  int stableSamples,qualityCap,targetFps;
  float scale=1f;
  public int TargetFps=>targetFps;
  public float RenderScale=>scale;
  void Start(){
   Application.runInBackground=false;
   int memory=SystemInfo.systemMemorySize;
   int gpu=SystemInfo.graphicsMemorySize;
   int cores=SystemInfo.processorCount;
   int count=QualitySettings.names.Length;
   qualityCap=count<=0?0:Mathf.Clamp((memory<4000||gpu<1500||cores<=4)?0:(memory<7000||gpu<3000)?1:2,0,count-1);
   if(count>0)QualitySettings.SetQualityLevel(qualityCap,true);
   scale=qualityCap==0?.8f:1f;
   targetFps=qualityCap==0?30:Mathf.Clamp(requestedFps,30,60);
   Apply();
  }
  void Apply(){
   Application.targetFrameRate=batterySaver?30:targetFps;
   QualitySettings.vSyncCount=0;
   ScalableBufferManager.ResizeBuffers(scale,scale);
  }
  public void SetBatterySaver(bool enabled){batterySaver=enabled;Apply();}
  void OnApplicationFocus(bool focused){ResetWindow();}
  void OnApplicationPause(bool paused){ResetWindow();}
  void ResetWindow(){elapsed=0;frames=0;stableSamples=0;}
  void Update(){
   if(!Application.isFocused||Time.unscaledDeltaTime<=0||Time.unscaledDeltaTime>.2f)return;
   elapsed+=Time.unscaledDeltaTime;frames++;
   if(elapsed<Mathf.Max(3,sampleSeconds))return;
   float fps=frames/elapsed;elapsed=0;frames=0;
   if(Time.unscaledTime-lastChange<changeCooldown)return;
   int desired=batterySaver?30:targetFps;
   if(fps<desired*.8f){
    stableSamples=0;
    if(scale>minimumRenderScale+.02f)scale=Mathf.Max(minimumRenderScale,scale-.1f);
    else if(QualitySettings.GetQualityLevel()>0)QualitySettings.DecreaseLevel(true);
    else if(targetFps>30)targetFps=30;
    lastChange=Time.unscaledTime;Apply();
   }else if(fps>desired*.96f){
    stableSamples++;
    if(stableSamples>=4){
     if(scale<.99f)scale=Mathf.Min(1,scale+.05f);
     else if(QualitySettings.GetQualityLevel()<qualityCap)QualitySettings.IncreaseLevel(true);
     stableSamples=0;lastChange=Time.unscaledTime;Apply();
    }
   }else stableSamples=0;
  }
 }
}