using System.Collections.Generic;
namespace BushehrBattle {
 public static class HeroCatalog {
  public static readonly IReadOnlyList<HeroDefinition> All=new List<HeroDefinition>{
   new HeroDefinition{id="cyrus",displayName="کوروش",damageMultiplier=1.25f},
   new HeroDefinition{id="xerxes",displayName="خشایارشا",defenseMultiplier=1.35f},
   new HeroDefinition{id="rostam",displayName="رستم",damageMultiplier=1.4f},
   new HeroDefinition{id="arash",displayName="آرش کمانگیر",fireRateMultiplier=1.3f},
   new HeroDefinition{id="darius",displayName="داریوش",damageMultiplier=1.1f,defenseMultiplier=1.1f},
   new HeroDefinition{id="surena",displayName="سورنا",fireRateMultiplier=1.25f},
   new HeroDefinition{id="ariobarzanes",displayName="آریوبرزن",defenseMultiplier=1.25f},
   new HeroDefinition{id="gordafarid",displayName="گردآفرید",damageMultiplier=1.2f},
   new HeroDefinition{id="kaveh",displayName="کاوه آهنگر",defenseMultiplier=1.3f},
   new HeroDefinition{id="babak",displayName="بابک خرمدین",damageMultiplier=1.15f}
  };
 }
}