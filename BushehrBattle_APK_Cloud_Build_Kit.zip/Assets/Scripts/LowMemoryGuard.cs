using UnityEngine;
namespace BushehrBattle {
 public class LowMemoryGuard : MonoBehaviour {
  public AdaptiveQuality adaptive;
  public bool unloadUnusedAssetsOnWarning=true;
  bool busy;
  void OnEnable(){Application.lowMemory+=HandleLowMemory;}
  void OnDisable(){Application.lowMemory-=HandleLowMemory;}
  float lastCleanup=-999f;
  public float cleanupCooldownSeconds=90f;
  void HandleLowMemory(){
   if(adaptive!=null)adaptive.SetBatterySaver(true);
   if(!busy&&unloadUnusedAssetsOnWarning&&Time.realtimeSinceStartup-lastCleanup>cleanupCooldownSeconds)StartCoroutine(Cleanup());
  }
  System.Collections.IEnumerator Cleanup(){
   busy=true;lastCleanup=Time.realtimeSinceStartup;
   yield return Resources.UnloadUnusedAssets();
   // Avoid synchronous GC.Collect during gameplay; it can cause long frame stalls.
   busy=false;
  }
 }
}