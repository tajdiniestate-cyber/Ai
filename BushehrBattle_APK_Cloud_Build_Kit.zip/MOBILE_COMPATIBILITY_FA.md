# گزارش سازگاری چندبرندی — V9

## دامنه
این ممیزی بر اساس مستندات رسمی Android و Unity و تحلیل مهندسی است؛ نظر یا تأیید مهندسان اپل، سامسونگ، شیائومی، موتورولا یا دیگر سازندگان نیست.

## اصلاحات کدنویسی‌شده
1. تشخیص اولیه توان سخت‌افزار با RAM، VRAM و تعداد هسته‌ها، نه نام برند.
2. محدودسازی FPS روی دستگاه‌های ضعیف و امکان حالت ذخیره باتری.
3. کاهش تدریجی رزولوشن رندر با ScalableBufferManager هنگام افت FPS.
4. جلوگیری از نوسان سریع کیفیت با cooldown و نمونه‌گیری پایدار.
5. نادیده گرفتن فریم‌های بسیار طولانی پس از بازگشت از پس‌زمینه.
6. مدیریت Pause/Resume، توقف صدا و بازگشت اندروید.
7. رعایت Safe Area برای بریدگی نمایشگر و گوشه‌های گرد.
8. واکنش به هشدار حافظه کم و آزادسازی منابع استفاده‌نشده.
9. تولید گزارش مشخصات دستگاه برای عیب‌یابی مدل‌های مختلف.
10. منوی ممیزی تنظیمات ساخت اندروید در Unity Editor.

## ماتریس بررسی دستگاه‌ها
- Apple iPhone/iPad: کدهای C# تا حدی مشترک هستند؛ ساخت iOS نیازمند Xcode/macOS، Metal، امضا و تست مستقل است. این بسته iOS را منتشر نمی‌کند.
- Samsung Galaxy: بررسی نرخ تازه‌سازی، Game Booster، دما، حافظه و نسبت تصویر روی دستگاه واقعی.
- Xiaomi/Redmi/POCO: بررسی مدیریت پس‌زمینه HyperOS، محدودیت باتری، GPU و مصرف حافظه.
- Motorola: بررسی تنوع چیپست، Android نزدیک به استاندارد، نسبت تصویر و چرخه حیات.
- OPPO/OnePlus/realme/vivo/iQOO: بررسی سیاست‌های مدیریت توان و نسخه‌های سیستم‌عامل.
- HONOR/Huawei: بررسی سازگاری API، نبود خدمات Google در برخی مدل‌ها و نصب مستقل.
- Tecno/Infinix/ZTE: بررسی RAM پایین، GPU ضعیف و نوسان حرارتی.

## ضعف‌های حل‌نشده
- کامپایل و اجرای Unity روی دستگاه واقعی انجام نشده است.
- سازگاری Vulkan/OpenGL ES باید در Player Settings و با تست عملی تأیید شود.
- GPU-specific texture compression, URP shaders, thermal sensors و Android Game Mode به تنظیم/پلاگین و تست دستگاه نیاز دارند.
- این بسته در خودکارسازی فشار حافظه، نرخ فریم و safe area کمک می‌کند، ولی تضمین عدم کرش نمی‌دهد.
- هنوز APK یا IPA ساخته نشده است.
- نقشه دقیق بوشهر و محتوای کامل بازی هنوز تکمیل نشده‌اند.

## منابع رسمی
https://developer.android.com/games/optimize/adpf
https://developer.android.com/games/engines/unity/unity-adpf
https://docs.unity.com/en-us/engine/6000.3/manual/analysis/runtime-performance-scaling/adaptive-performance/introduction
https://docs.unity3d.com/6000.0/Documentation/Manual/system-requirements.html
